Config.Names1 = {
    "yummy","amazeballs","savory", "lights-out","humblebrag","medal","chill", 
    "jailbreak", "streetdance", "mobhand", "spoiler","hokum","admired","darling",
    "endeared","esteemed","idolized","revered","choice","elegant","ravishing",
    "seductive","bonny","cute","elegant","rare","superior","euphoric","bravado",
    "Aardvark","Aardwolf","Buffalo","Elephant","Leopard","Albatross","Alligator",
    "Alpaca","Bison","Robin","Amphibian","Anaconda","Angelfish","Anglerfish","Ant",
    "Anteater","Antelope","Antlion","Ape","Aphid","Leopard","Fox","Wolf","Armadillo",
    "Crab","Asp","Donkey","Baboon","Badger","Eagle","orca", "whale", "guppy",
    "lamprey", "catshark", "sparrow", "shark", "rabbit", "marmot", "tiger", "owl", "pony", "dakota",
    "ferret", "cobra", "scallop", "hamster", "kangaroo", "porpoise", "gecko", "koi", "moose", "lobster",
    "rook", "centipede"
}

Config.Names2 = {
    "cake","candy", "dainty", "jam", "treat", "pudding","tart", 
    "confection", "delight","dessert","joy","bonbon", "confection","ambrosia","luxury",
    "nectar","rarity","special","treat","bonbon","passion","fruit",
    "berry","bliss","charm","delight","glee","gem","luxury","treasure","snack","raven",
    "tarantula", "python", "grouse", "lizard", "porcupine", "hedgehog", "loon", "silkworm",
    "vanilla", "chocolate", "pizza", "spaghetti", "garlic", "salt", "mayo", "red", "blue",
    "yellow", "mustard", "lime"
}