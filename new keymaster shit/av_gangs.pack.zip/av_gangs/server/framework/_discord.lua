local webhook = "YOUR_WEBHOOK_GOES_HERE"

function Discord(message)
    exports['av_laptop']:Discord(webhook, message)
end