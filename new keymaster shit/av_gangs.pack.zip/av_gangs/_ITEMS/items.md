**For QBCore/shared/items.lua**
['spray'] = {['name'] = 'spray', ['label'] = 'Spray', ['weight'] = 500, ['type'] = 'item', ['image'] = 'spray.png', ['unique'] = true, ['useable'] = true, 	['shouldClose'] = true, ['combinable'] = nil, ['description'] = ''},
['spray_remover'] = {['name'] = 'spray_remover', ['label'] = 'Spray Remover', ['weight'] = 500, ['type'] = 'item', ['image'] = 'spray_remover.png', ['unique'] = true, ['useable'] = true, 	['shouldClose'] = true, ['combinable'] = nil, ['description'] = ''},

**For Ox_inventory/data/items.lua**
['spray'] = {
    label = 'Spray',
    weight = 1,
    stack = true,
    close = true,
    description = ''
},
['spray_remover'] = {
    label = 'Spray Remover',
    weight = 1,
    stack = true,
    close = true,
    description = ''
},

**For Quasar Inventory qs-core/config/config_items**
["spray"] = {
    ["name"] = "spray",
    ["label"] = "Spray",
    ["weight"] = 1,
    ["type"] = "item",
    ["image"] = "spray.png",
    ["unique"] = false,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = ""
},
["spray_remover"] = {
    ["name"] = "spray_remover",
    ["label"] = "Spray Remover",
    ["weight"] = 1,
    ["type"] = "item",
    ["image"] = "spray_remover.png",
    ["unique"] = false,
    ["useable"] = true,
    ["shouldClose"] = true,
    ["combinable"] = nil,
    ["description"] = ""
},