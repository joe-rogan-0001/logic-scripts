RegisterNetEvent('av_restaurant:duty', function(data)
    TriggerServerEvent('av_restaurant:duty')
end)