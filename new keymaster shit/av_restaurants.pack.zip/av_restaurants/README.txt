Documentation: https://docs.av-scripts.com/
If you need support open a Ticket on Discord: https://discord.com/invite/SXSZT6q