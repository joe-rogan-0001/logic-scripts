fx_version 'cerulean'
game 'gta5'
this_is_a_map 'yes'

files {		
	"audio/*.dat151.rel",
}

data_file "AUDIO_GAMEDATA" "audio/5d_sewers_col_game.dat"
data_file "AUDIO_DYNAMIXDATA" "audio/5d_sewers_col_mix.dat"
data_file "AUDIO_GAMEDATA" "audio/5d_sewers_doors_game.dat"
dependency '/assetpacks'