insideMotel = false

exports("inMotel", function()
    return insideMotel
end)