function HideHud(hide)
    if hide then
        -- Hide hud event
    else
        -- Show hud event
    end
end