**For QBCore/shared/items.lua**
['laptop'] = {['name'] = 'laptop', ['label'] = 'Laptop', ['weight'] = 500, ['type'] = 'item', ['image'] = 'laptop.png', ['unique'] = true, ['useable'] = true, ['shouldClose'] = true, ['combinable'] = nil, ['description'] = ''},

['decrypter'] = {['name'] = 'decrypter', ['label'] = 'Decrypter', ['weight'] = 500, ['type'] = 'item', ['image'] = 'decrypter.png', ['unique'] = false, ['useable'] = false, ['shouldClose'] = false, ['combinable'] = nil, ['description'] = ''},

['black_usb'] = {['name'] = 'black_usb', ['label'] = 'Black USB', ['weight'] = 500, ['type'] = 'item', ['image'] = 'black_usb.png', ['unique'] = false, ['useable'] = false, ['shouldClose'] = false, ['combinable'] = nil, ['description'] = ''},

**For Ox_inventory/data/items.lua**
['laptop'] = {
label = 'Laptop',
weight = 1,
stack = false,
close = true,
description = ''
},
['decrypter'] = {
label = 'Decrypter',
weight = 1,
stack = true,
close = true,
description = ''
},
['black_usb'] = {
label = 'Black USB',
weight = 1,
stack = true,
close = true,
description = ''
},

**For Quasar Inventory qs-core/config/config_items**
["laptop"] = {
["name"] = "laptop",
["label"] = "Laptop",
["weight"] = 1,
["type"] = "item",
["image"] = "laptop.png",
["unique"] = true,
["useable"] = true,
["shouldClose"] = true,
["combinable"] = nil,
["description"] = ""
},
["decrypter"] = {
["name"] = "decrypter",
["label"] = "Decrypter",
["weight"] = 1,
["type"] = "item",
["image"] = "decrypter.png",
["unique"] = false,
["useable"] = false,
["shouldClose"] = false,
["combinable"] = nil,
["description"] = ""
},
["black_usb"] = {
["name"] = "black_usb",
["label"] = "Black USB",
["weight"] = 1,
["type"] = "item",
["image"] = "black_usb.png",
["unique"] = false,
["useable"] = false,
["shouldClose"] = false,
["combinable"] = nil,
["description"] = ""
},
