Lang = {
    ['app_title'] = "Laptop System",
    ['settings_updated'] = "Changes saved",
    ['title'] = "Low Battery",
    ['new_laptop'] = "Your new laptop has been configured, you can use it now.",
    ['no_battery'] = "Your laptop battery is low, go to a chargin station.",
    ['added_to_clipboard'] = "Added to clipboard.",
    -- Alert Owner
    ['alert_title'] = "Important",
    ['alert_description'] = "Your laptop has been hacked, check your GPS.",
    -- Cupcake Swap
    ['cupcake_title'] = "Cupcake Swap",
    ['wrong_id'] = "User not found",
    ['bought'] = "You bought",
    ['sold'] = "You sold",
    ['received'] = "and received",
    ['sent'] = "You sent",
    ['crypto'] = "cosmo",
    ['no_money'] = "You don't have enough money.",
    ['money_sign'] = "$",
    -- Wifi
    ['wifi_title'] = "WiFi Settings",
    ['weak_wifi'] = "Wifi signal is too weak",
    -- Stations
    ['interact'] = "[E] Open Station",
    ['charging_station'] = "Charging Station",
    ['reset_station'] = "Reset Station",
    ['laptop_is_ready'] = "The laptop has been restored",
    ['open_stash'] = "Open Stash",
    ['reset_laptop'] = "Reset Laptop",
}