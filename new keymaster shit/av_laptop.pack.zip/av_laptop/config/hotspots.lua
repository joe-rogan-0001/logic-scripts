--[[
    name: unique identifier
    label: How the player will see it in laptop
    password: I think is obvious?
    coords: The wifi network location

    The player will lose connection if it gets more than 60mts away from the coords
]]
HotspotList = {
    {name = "uwucafe", label = "UwU Customers", password = false, coords = {-580.3973, -1059.5032, 22.3442}},
    {name = "vanilla_employees", label = "Vanilla Employees", password = "123", coords = {114.7914, -1286.0952, 28.2621}},
}