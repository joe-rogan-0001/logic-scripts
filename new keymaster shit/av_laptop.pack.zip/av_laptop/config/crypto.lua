-- This is for QBCore only
Config.UsingCustomCrypto = false -- True if you are using crypto stored in player metadata (for example renewed core cryptos)
Config.CustomCryptos = { -- List of available cryptos, make sure they are named exactly as yours
    ["shung"] = true,
    ["gne"] = true,
    ["xcoin"] = true,
    ["lme"] = true,
}