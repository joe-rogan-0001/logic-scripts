Made by Rep Scripts
Discord: https://discord.gg/WK7nYmDhrN (24/7 support and updates)
Tebex: https://rep.tebex.io/

# **INSTALLATION VIDEO GUIDE**

https://youtu.be/rBnhWZc61AU

# Dependencies

- [QBCore Framework](https://github.com/qbcore-framework)
- [QB-Input](https://github.com/qbcore-framework/qb-input)
- [QB-Menu](https://github.com/qbcore-framework/qb-menu)
- [OXlib](https://github.com/overextended/ox_lib)
- [Renewed-Weaponscarry](https://github.com/Renewed-Scripts/Renewed-Weaponscarry)
- [OX Inventory](https://github.com/overextended/ox_inventory)
- [QB Inventory]()

# Installation:

https://rep-scripts.gitbook.io/rep-scripts/
